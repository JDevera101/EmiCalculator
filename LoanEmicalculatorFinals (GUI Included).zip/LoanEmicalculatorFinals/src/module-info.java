/**
 * 
 */
/**
 * 
 */
module LoanEmicalculatorFinals {
	requires java.desktop;
}